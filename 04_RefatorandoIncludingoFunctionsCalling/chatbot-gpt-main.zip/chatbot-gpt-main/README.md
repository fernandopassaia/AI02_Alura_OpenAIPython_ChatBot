# chatbot-gpt

Repository created to learn how to create a chatbot using GPT, Python and Flask.